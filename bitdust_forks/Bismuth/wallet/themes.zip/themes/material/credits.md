# Theme credits

Based upon Material Dashboard Dark Edition by Creative Tim   
https://www.creative-tim.com/product/material-dashboard-dark

MIT Licence
