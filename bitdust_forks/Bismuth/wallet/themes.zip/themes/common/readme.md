# Extra static path, /common

To be used by all themes so to factorize the generic files they could need.
