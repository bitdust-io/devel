# Crystals

Crystals are like plugins you can add to your wallet.    
They can query external APIs and bring extra functionality to your wallet.

See /doc/crystals.md
