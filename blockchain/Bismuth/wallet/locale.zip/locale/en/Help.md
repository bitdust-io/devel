# User Guide

This is the reference User guide for the Bismuth Tornado Wallet.

# WIP

Each language will have its own localized `Help.md` in the matching "locale" dir.  
